<?
        header("Location: login.php");
?>
