<?php
include_once ('./config.php');
include_once('./editor_functions.php');
include_once ('./includes/common.php');
include_once ('./lang/'.$lang_include);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<head>
<style type="text/css">
<!--
 body   {font-family:Verdana; font-size:12px; background-color: threedface;}
-->
</style>
</head>
<body>
<div align="center"> <br>
	<br>
	<?php echo $lang['no_preview']; ?></div>
</body>
</html>
