function openShare()
{
  var fs = window.open( "share?v=f-IDNOL7dkU" ,
           "ShareVideo", "toolbar=no,width=" + 500  + ",height=" + 400
         + ",status=no,resizable=yes,fullscreen=no");
  fs.focus();
}


